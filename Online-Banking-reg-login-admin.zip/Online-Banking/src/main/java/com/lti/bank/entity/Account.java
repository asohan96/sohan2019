/*package com.lti.bank.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="TBL_AccountDetails")
public class Account {
	
	@OneToOne
	@JoinColumn(name="accountNumber")
	private OpenAccount openAccount;
	private long accountNumber;
	private String accountType;
	private double balance;
	@OneToMany(mappedBy="account",cascade=CascadeType.ALL)
	private List<Transaction> transaction;
	
	
	
}
*/
package com.lti.bank.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lti.bank.component.AdminLoginException;
import com.lti.bank.dto.AdminDto;
import com.lti.bank.entity.AdminCredentials;
import com.lti.bank.entity.OpenAccount;

@Repository 
public class AdminLoginDao {
	
@PersistenceContext
private EntityManager entityManager;

public AdminCredentials fetchAdmin(AdminDto adminDto)throws AdminLoginException  {
	
	Query query = entityManager.createQuery("select credentials from AdminCredentials as credentials where credentials.userName = :userName and credentials.password = :password");
	query.setParameter("userName", adminDto.getUserName());
	query.setParameter("password", adminDto.getPassword());
	
	try {
		return (AdminCredentials) query.getSingleResult();
	} catch (NoResultException e) {
		throw new AdminLoginException("Please try again with valid username and password!");
	}
}


public List<OpenAccount> fetchApplications() {
	Query query = entityManager.createQuery("select account from OpenAccount as account");
	List<OpenAccount> applicationList = query.getResultList();
	return applicationList;
}
public OpenAccount fetchSingleApplication(long accountNumber) {
	Query query = entityManager.createQuery("select application from OpenAccount as application where application.accountNumber = :accountNumber");
	query.setParameter("accountNumber", accountNumber);
	OpenAccount application = (OpenAccount) query.getSingleResult();
	return application;
}
@Transactional
public void approveApplication(long accountNumber) {
	Query query = entityManager.createQuery("update OpenAccount set isApproved = true where accountNumber = :accountNumber");
	query.setParameter("accountNumber", accountNumber).executeUpdate();
}

}

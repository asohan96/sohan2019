package com.lti.bank.dao;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.lti.bank.component.AtlanticException;
import com.lti.bank.dto.AccountLoginDTO;
import com.lti.bank.dto.CredentialsDTO;
import com.lti.bank.dto.PasswordDTO;
import com.lti.bank.entity.InternetBanking;

@Repository
public class LoginDao {
	@Autowired
	GenericDao genericDao;
	@PersistenceContext
	EntityManager entityManager;
	public InternetBanking setNewPassword(InternetBanking internetBanking)
	{
		return entityManager.merge(internetBanking);
	}
	public InternetBanking validateAnswer(PasswordDTO passwordDTO) {
		Query query = entityManager.createQuery("select b from InternetBanking as b where b.answer = :answer");
		query.setParameter("answer", passwordDTO.getAnswer());
		try {
			return (InternetBanking) query.getSingleResult();
		} catch (NoResultException e) {
			throw new AtlanticException("Problem in answer");
		}
	}


	@Transactional
	public void updateCredentials(CredentialsDTO credentialsDTO, InternetBanking internetBanking) {
		Query query = entityManager
				.createQuery("update InternetBanking as e set e.loginPassword=:newLoginPassword,e.transactionPassword=:newTransactionPassword where e.userId=:userId");
		query.setParameter("userId", internetBanking.getUserId());
		query.setParameter("newLoginPassword", credentialsDTO.getNewLoginPassword());
		query.setParameter("newTransactionPassword", credentialsDTO.getNewTransactionPassword());
		query.executeUpdate();
	}
	@Transactional
	public void updatePassword(PasswordDTO passwordDTO,@ModelAttribute("forgot-password1") InternetBanking internetBanking) {
		Query query = entityManager
				.createQuery("update InternetBanking as e set e.loginPassword=:loginPassword where e.userId=:userId");
		query.setParameter("userId", internetBanking.getUserId());
		query.setParameter("loginPassword", passwordDTO.getLoginPassword());
		query.executeUpdate();
	}

	public InternetBanking validateCredentials(AccountLoginDTO accountLoginDTO)throws AtlanticException  {
		
		Query query = entityManager.createQuery("select credentials from InternetBanking as credentials where credentials.userId = :userId and credentials.loginPassword = :loginPassword");
		query.setParameter("userId", accountLoginDTO.getUserId());
		query.setParameter("loginPassword", accountLoginDTO.getLoginPassword());
		
		try {
			return (InternetBanking) query.getSingleResult();
		} catch (NoResultException e) {
			throw new AtlanticException("Please try again with valid username and password!");
		}
	}

	
	public InternetBanking findUserId(long userId) {
		// TODO Auto-generated method stub
		return null;
	}
}


/*public InternetBanking validateCredentials(AccountLoginDTO accountLoginDTO) {
//genericDao.find(InternetBanking.class, accountLoginDTO.getUserId());
Query query = entityManager.createQuery("select u from InternetBanking as u where u.userId = :serId and u.loginPassword = :oginPassword");
query.setParameter("serId", accountLoginDTO.getUserId());
query.setParameter("oginPassword", accountLoginDTO.getLoginPassword());

	System.out.println( (InternetBanking) query.getSingleResult());
	try{return (InternetBanking) query.getSingleResult(); 
	}
	catch (NoResultException nre) {
	throw new AtlanticException("Problem in user credentials");
	}
}*/

package com.lti.bank.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import com.lti.bank.dto.PasswordDTO;
import com.lti.bank.entity.InternetBanking;
import com.lti.bank.service.ChangePasswordService;

@Controller
@SessionAttributes("forgot-password1")
public class AccountPasswordController {
	boolean successfullOpen;
	@Autowired
	private ChangePasswordService changePasswordService;
	
	@RequestMapping(path="/forgot-password", method=RequestMethod.POST)
	public String checkUser(PasswordDTO passwordDTO,Map<String, Object> model) {		
	InternetBanking isUser=changePasswordService.isValidUser(passwordDTO);
	if(isUser==null)
		return "/atlantic-no-userid.jsp";
	else {
		model.put("forgot-password1", isUser);
		return "/atlantic-security-check.jsp";
	}
	}

	@RequestMapping(path="/check-answer", method=RequestMethod.POST)
	public String checkAnswer(PasswordDTO passwordDTO,Model model) {		
		boolean correctAnswer = changePasswordService.checkAnswer(passwordDTO);
	if(correctAnswer==true)
		return "/atlantic-change-password.jsp";
	else
		model.addAttribute("error", "Incorrect Answer...!!");
		return "/atlantic-security-check.jsp";
			
	}
	
	@RequestMapping(path = "/set-new-password", method = RequestMethod.POST)
	public String resetProcess(PasswordDTO passwordDTO,@ModelAttribute("forgot-password1") InternetBanking internetBanking ) {

		changePasswordService.resetPassword(passwordDTO,internetBanking);
		return "/atlantic-sign-in.jsp";
	}


}

package com.lti.bank.controller;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lti.bank.component.AtlanticException;
import com.lti.bank.dto.OpenAccountDTO;
import com.lti.bank.entity.OpenAccount;
import com.lti.bank.service.OpenAccountService;

@Controller
public class OpenAccountController {
	OpenAccount successfullOpen;
	@Autowired
	private OpenAccountService openAccountService;
	
	@RequestMapping(path="/open-account", method=RequestMethod.POST)
	public String openAccount(OpenAccountDTO openAccountDTO,Map<String, Object> model) {		
		File targetDir = new File("d:/uploads/" + openAccountDTO.getAadharCardFile().getOriginalFilename()); 
		try {
			openAccountDTO.getAadharCardFile().transferTo(targetDir);
		}
		catch (IOException e) {
			throw new AtlanticException("Copy Failed");
		
		}
		successfullOpen=openAccountService.openAccountService(openAccountDTO);
	if(successfullOpen!=null) 	{
		//	long accountNumber = openAccountService.fetchAccountNumber(openAccountDTO);
			openAccountDTO.setAccountNumber(successfullOpen.getAccountNumber());
			model.put("openAccountDetails", openAccountDTO);
		return "/atlantic-account-application-successfull.jsp";}
		else
			return "/atlantic-account-application-unsuccessfull.jsp";
			
	}
	//to fetch details from Account Table
	@RequestMapping(path="/list", method=RequestMethod.GET)
	public String list(Map<String, Object> model) {
		List<OpenAccount> list = openAccountService.getshowAccountDetails();
		model.put("listOfDetails", list);
		return "/atlantic-dashboard-fancy.jsp";
	}
}

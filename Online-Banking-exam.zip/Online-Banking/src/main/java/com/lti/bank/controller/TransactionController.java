package com.lti.bank.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lti.bank.component.AtlanticException;
import com.lti.bank.dto.FundTransferDTO;
import com.lti.bank.service.TransactionService;

@Controller
public class TransactionController {

	@Autowired
	private TransactionService transactionService;

	@RequestMapping(path="/transaction",method= RequestMethod.POST)
	public String fundTransfer(FundTransferDTO fundTransferDTO,Map<String,Object> model) {
		boolean success;
		success=transactionService.MoneyTransfer(fundTransferDTO);
			if(success)
				{model.put("msg", "Transaction Successfull.");
		return "/atlantic-dashboard-fancy.jsp";
				}else {
				model.put("msg", "Transaction Failed..enter valid accounts please.");
			return "/atlantic-dashboard-fancy.jsp";
	}
			}
}

/*package com.lti.bank.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name="TBL_AccountDetails")
public class Account {
	
	@OneToOne
	@JoinColumn(name="accountNumber")
	private OpenAccount openAccount;
	private String accountType;
	private double balance;
	@OneToMany(mappedBy="account",cascade=CascadeType.ALL)
	private List<Transaction> transactions;
	public OpenAccount getOpenAccount() {
		return openAccount;
	}
	public void setOpenAccount(OpenAccount openAccount) {
		this.openAccount = openAccount;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public List<Transaction> getTransactions() {
		return transactions;
	}
	public void setTransactions(List<Transaction> transactions) {
		this.transactions = transactions;
	}
}
*/
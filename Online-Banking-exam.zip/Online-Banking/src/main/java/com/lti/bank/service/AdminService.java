package com.lti.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.lti.bank.component.AdminLoginException;
import com.lti.bank.dao.AdminLoginDao;
import com.lti.bank.dto.AdminDto;
import com.lti.bank.entity.AdminCredentials;
import com.lti.bank.entity.OpenAccount;

@Service
@Component
public class AdminService {
	
	@Autowired
	private AdminLoginDao loginDao;
	
	public boolean getAdmin(AdminDto adminDto) {
	
			try {
				AdminCredentials credentials = loginDao.fetchAdmin(adminDto);
				return true;
			} catch (AdminLoginException e) {
				return false;
			}
		}
	public List<OpenAccount> fetchAccountApplications() {
		return loginDao.fetchApplications();
	}
	public OpenAccount fetchSingleApplication(long accountNumber) {
		return loginDao.fetchSingleApplication(accountNumber);
	}
	public void approveApplication(long accountNumber) {
		loginDao.approveApplication(accountNumber);
	}
	public void rejectApplication(long accountNumber) {
		loginDao.rejectApplication(accountNumber);
	}
	
}
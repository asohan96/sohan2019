package com.lti.bank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.lti.bank.component.AtlanticException;
import com.lti.bank.dao.GenericDao;
import com.lti.bank.dao.LoginDao;
import com.lti.bank.dto.CredentialsDTO;
import com.lti.bank.dto.PasswordDTO;
import com.lti.bank.entity.InternetBanking;

@Service
public class ChangePasswordService {
	@Autowired
	private LoginDao loginDao;
	@Autowired
	private GenericDao genericDao;


	public InternetBanking isValidUser(PasswordDTO passwordDTO) {
		InternetBanking internetBanking = genericDao.find(InternetBanking.class, passwordDTO.getUserId());
		return internetBanking;
	}

	public boolean checkAnswer(PasswordDTO passwordDTO) {
		try {
			 InternetBanking ans = loginDao.validateAnswer(passwordDTO);
			return true;
		} catch (AtlanticException e) {
			return false;
		}
}
	public void resetPassword(PasswordDTO passwordDTO,@ModelAttribute("forgot-password1") InternetBanking internetBanking) {
		loginDao.updatePassword(passwordDTO, internetBanking);
	}

	public boolean changePassword(CredentialsDTO dto,long id) {
	loginDao.updateCredentials(dto, id);
	
	
		return true;
	}
}

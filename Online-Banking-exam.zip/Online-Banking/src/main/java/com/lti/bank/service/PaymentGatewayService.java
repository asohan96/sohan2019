package com.lti.bank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.bank.dao.GenericDao;
import com.lti.bank.dto.SecondaryAccountDTO;
import com.lti.bank.entity.OpenAccount;
import com.lti.bank.entity.Transaction;

@Service
public class PaymentGatewayService {
	@Autowired
	private GenericDao genericDao;



	public OpenAccount toSecondaryWithAmount(SecondaryAccountDTO paymentGatewayDTO) {
		OpenAccount secondaryAcc = genericDao.find(OpenAccount.class, paymentGatewayDTO.getPartnerAcno());
		return secondaryAcc;
	}

	public OpenAccount getAccount(long acno) {

		OpenAccount primaryAcc = genericDao.find(OpenAccount.class, acno);
		return primaryAcc;
	}

	@Transactional
	public boolean transfer(OpenAccount secondaryAcc, OpenAccount primaryAcc, double txAmount) {
		if (primaryAcc.getBalance() >= txAmount) {

			Transaction tx1 = new Transaction();

			tx1.setAmount(txAmount);
			tx1.setOpenAccount(primaryAcc);
			tx1.setTransactionType("Debited");
			tx1.setTransactionMode("Payment");
			Transaction tx2 = new Transaction();
			tx2.setAmount(txAmount);
			tx2.setOpenAccount(secondaryAcc);
			tx2.setTransactionType("Credited");
			tx2.setTransactionMode("Payment");
			
			primaryAcc.setBalance(primaryAcc.getBalance() - txAmount);
			secondaryAcc.setBalance(secondaryAcc.getBalance() + txAmount);

			genericDao.save(primaryAcc);
			genericDao.save(secondaryAcc);

			genericDao.save(tx1);
			genericDao.save(tx2);
			
			return true;
		}
		return false;
		
	}
}

package com.lti.bank.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.bank.dao.AccountDao;
import com.lti.bank.dto.OpenAccountDTO;
import com.lti.bank.entity.OpenAccount;
import com.lti.bank.entity.InternetBanking;

@Service
public class OpenAccountService {
	@Autowired
	private AccountDao accountDao;	
	@Transactional
	public OpenAccount openAccountService(OpenAccountDTO openAccountDTO) {
	
		double savingInitialBalance=1000;	
		if ((openAccountDTO.getBalance() >= savingInitialBalance && openAccountDTO.getAccountType().equals("SavingAccount")) || openAccountDTO.getAccountType().equals("CurrentAccount"))
		{		OpenAccount accountApplication = new OpenAccount();
			
			accountApplication.setAccountType(openAccountDTO.getAccountType());
			accountApplication.setAccountDate(new Date());
			accountApplication.setTitle(openAccountDTO.getTitle());
			accountApplication.setFirstName(openAccountDTO.getFirstName());
			accountApplication.setMiddleName(openAccountDTO.getMiddleName());
			accountApplication.setLastName(openAccountDTO.getLastName());
		
			accountApplication.setMobileNumber(openAccountDTO.getMobileNumber());
			accountApplication.setEmailId(openAccountDTO.getEmailId());
			accountApplication.setAadharCardNumber(openAccountDTO.getAadharCardNumber());
			try {
				Date date = new SimpleDateFormat("yyyy-MM-dd").parse(openAccountDTO.getDateOfBirth());
				accountApplication.setDateOfBirth(date);
			} catch (ParseException e) {
			}
			accountApplication.setResidentialAddressLine1(openAccountDTO.getResidentialAddressLine1());
			accountApplication.setResidentialAddressLine2(openAccountDTO.getResidentialAddressLine2());
			accountApplication.setResidentialLandmark(openAccountDTO.getResidentialLandmark());
			accountApplication.setResidentialState(openAccountDTO.getResidentialState());
			accountApplication.setResidentialCity(openAccountDTO.getResidentialCity());
			accountApplication.setResidentialPincode(openAccountDTO.getResidentialPincode());
			accountApplication.setPermanentAddressLine1(openAccountDTO.getPermanentAddressLine1());
			accountApplication.setPermanentAddressLine2(openAccountDTO.getPermanentAddressLine2());
			accountApplication.setPermanentLandmark(openAccountDTO.getPermanentLandmark());
			accountApplication.setPermanentState(openAccountDTO.getPermanentState());
			accountApplication.setPermanentCity(openAccountDTO.getPermanentCity());
			accountApplication.setPermanentPincode(openAccountDTO.getPermanentPincode());
			accountApplication.setAtmCard(openAccountDTO.getAtmCard());
			System.out.println(accountApplication.getAccountNumber());		
			String b="ATL01";
			accountApplication.setIfscCode(b);
			accountApplication.setOccupationType(openAccountDTO.getOccupationType());
			accountApplication.setGrossAnnualIncome(openAccountDTO.getGrossAnnualIncome());
			accountApplication.setBalance(openAccountDTO.getBalance());
			accountApplication.setAadharCardFileName(openAccountDTO.getAadharCardFile().getOriginalFilename());
			OpenAccount acc=accountDao.accountApproval(accountApplication);
			
			InternetBanking netbanking = new InternetBanking();
			netbanking.setOpeningAccount(acc);
			netbanking.setUserId(acc.getAccountNumber());
			netbanking.setLoginPassword(openAccountDTO.getLoginPassword());
			netbanking.setTransactionPassword(openAccountDTO.getTransactionPassword());
			netbanking.setSecurityQuestion(openAccountDTO.getSecurityQuestion());
			netbanking.setAnswer(openAccountDTO.getAnswer());
			accountDao.registerForInternetBanking(netbanking);
			return acc;
		}
		else
			return null;
	}
	public List<OpenAccount> getshowAccountDetails() {
		return accountDao.fetchAll();
	}
}

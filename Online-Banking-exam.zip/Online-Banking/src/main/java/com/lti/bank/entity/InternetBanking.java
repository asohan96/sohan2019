package com.lti.bank.entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="TBL_AccountLoginCredentials")
public class InternetBanking {
	
	@Id
	private long userId;
	
	@OneToOne
	@JoinColumn(name="accountNumber")
	private OpenAccount openAccount;
	private String loginPassword;
	private String transactionPassword;
	private String securityQuestion;
	@Column(name = "answer",unique=true)
	private String answer;
	
	
	public String getSecurityQuestion() {
		return securityQuestion;
	}
	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getLoginPassword() {
		return loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	public String getTransactionPassword() {
		return transactionPassword;
	}

	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}

	public OpenAccount getOpenAccount() {
		return openAccount;
	}
	public void setOpeningAccount(OpenAccount openAccount) {
		this.openAccount = openAccount;
	}

}
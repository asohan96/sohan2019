package com.lti.bank.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class RegisterForInternetBanking {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}

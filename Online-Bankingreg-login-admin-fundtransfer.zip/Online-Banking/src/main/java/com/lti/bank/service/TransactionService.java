package com.lti.bank.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.bank.component.AtlanticException;
import com.lti.bank.dao.GenericDao;
import com.lti.bank.dto.FundTransferDTO;
import com.lti.bank.entity.OpenAccount;
import com.lti.bank.entity.Transaction;

@Service
public class TransactionService {

	// @Autowired
	// private TransactionRepo transactionrepo;

	/* @Autowired
	 private TransactionDao transdao;
*/
	@Autowired
	private GenericDao genericDao;

	@Transactional
	public boolean MoneyTransfer(FundTransferDTO fundTransferDTO) {
		long ac1 = fundTransferDTO.getFromAccount();
		long ac2 = fundTransferDTO.getToAccount();
		OpenAccount a1 = genericDao.find(OpenAccount.class, fundTransferDTO.getFromAccount());
		OpenAccount a2 = genericDao.find(OpenAccount.class, fundTransferDTO.getToAccount());
		if(a1!=null && a2!=null)
		{
			
		
		Transaction tx1 = new Transaction();
		tx1.setAmount(fundTransferDTO.getAmount());
		tx1.setOpenAccount(a1);
		tx1.setTransactionType("Money Transfered");
		tx1.setTransactionDate(new Date());
		tx1.setTransactionMode(fundTransferDTO.getTransactionMode());
		Transaction tx2 = new Transaction();
		tx2.setAmount(fundTransferDTO.getAmount());
		tx2.setOpenAccount(a2);
		tx2.setTransactionType("Money Received");
		tx2.setTransactionDate(new Date());
		tx2.setTransactionMode(fundTransferDTO.getTransactionMode());
		a1.setBalance(a1.getBalance() - fundTransferDTO.getAmount());
		a2.setBalance(a2.getBalance() + fundTransferDTO.getAmount());

		genericDao.save(a1);
		genericDao.save(a2);

		genericDao.save(tx1);
		genericDao.save(tx2);
		return true;}
		else
			return false;
	}
}
	
	























/*	public double checkBalance(long accountNumber) {
GenericDao dao = new GenericDao();
Account account = dao.fetch(Account.class, 12345L);
return account.getBalance();
}*/

/*public List<Transaction> miniStatement(long accountNumber) {
return transdao.miniStatement(12345L);
}*/




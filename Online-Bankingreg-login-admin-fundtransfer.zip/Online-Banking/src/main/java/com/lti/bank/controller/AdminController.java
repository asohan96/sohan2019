package com.lti.bank.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.lti.bank.dto.AdminDto;
import com.lti.bank.entity.OpenAccount;
import com.lti.bank.service.AdminService;

@Controller
public class AdminController {

	@Autowired
	private AdminService adminService;

	@RequestMapping(path = "/adminCredentials", method = RequestMethod.POST)
	public String adminLogin(AdminDto adminDto) {
		boolean isValidAdmin = adminService.getAdmin(adminDto);
		if (isValidAdmin)
			return "/adminDashboard.jsp";
		else
			return "/loginError.jsp";
	}

	@RequestMapping(path = "/fetchApplications", method = RequestMethod.GET)
	public String fetchAccountApplications(Map<String, Object> model) {
		List<OpenAccount> applications = adminService.fetchAccountApplications();
		model.put("applicationList", applications);
		return "/ViewApplications.jsp";
	}
	
	//to view 
	@RequestMapping(path="/viewSingleApplication", method=RequestMethod.GET)
	public String viewSingleApplication(Map<String, Object> model, 
																		@RequestParam("accountNumber") long accountNumber) {
		OpenAccount application = adminService.fetchSingleApplication(accountNumber);
		model.put("currentApplication", application);
		return "/adminViewSingleApplication.jsp";
	}
	
	@RequestMapping(path="/approveApplication", method=RequestMethod.GET)
	public String approveApplication(@RequestParam("applicationNo") long accountNumber) {
		adminService.approveApplication(accountNumber);
		return "/adminDashboard.jsp";
	}
	@RequestMapping(path="/rejectApplication", method=RequestMethod.GET)
	public String rejectApplication(@RequestParam("applicationNo") long accountNumber) {
		adminService.rejectApplication(accountNumber);
		return "/adminDashboard.jsp";
	}
}

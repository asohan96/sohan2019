package com.lti.bank.controller;

import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

public class LogOutController {

	@RequestMapping(path="/logOut", method = RequestMethod.POST)
	public String logOut(HttpSession session){
	session.invalidate();
	return "redirect:/adminLogin.jsp";
	}
	}

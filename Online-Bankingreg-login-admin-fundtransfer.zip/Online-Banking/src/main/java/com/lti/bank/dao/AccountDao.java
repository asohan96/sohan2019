package com.lti.bank.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;


import com.lti.bank.entity.OpenAccount;
import com.lti.bank.entity.InternetBanking;

@Repository
public class AccountDao {
	
	@PersistenceContext
	protected EntityManager entityManager;

	public OpenAccount accountApproval(OpenAccount accountApplication)
	{
		OpenAccount accountApp=entityManager.merge(accountApplication);
		  return accountApp;
	}
		
	public OpenAccount fetchAccount(long accountNumber) {
		return entityManager.find(OpenAccount.class, accountNumber);

	}
	
	public void registerForInternetBanking(InternetBanking netBank) {
		
		entityManager.merge(netBank);
	}

	public List<OpenAccount> fetchAll() {
		return entityManager.createQuery("select  r from OpenAccount r").getResultList();
	}	
}

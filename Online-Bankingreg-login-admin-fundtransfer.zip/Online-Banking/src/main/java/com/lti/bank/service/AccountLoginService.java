package com.lti.bank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.bank.component.AtlanticException;
import com.lti.bank.dao.AccountDao;
import com.lti.bank.dao.LoginDao;
import com.lti.bank.dto.AccountLoginDTO;
import com.lti.bank.entity.InternetBanking;
import com.lti.bank.entity.OpenAccount;

@Service
public class AccountLoginService {
		
	@Autowired
		private LoginDao loginDao;
	@Autowired
	private AccountDao accountDao;
		
	public OpenAccount validAccountUser(AccountLoginDTO accountLoginDTO)
	{
		//InternetBanking internetBanking = loginDao.findUserId(accountLoginDTO.getUserId());
		InternetBanking internetBanking=loginDao.validateCredentials(accountLoginDTO);
		if(internetBanking != null) {
			OpenAccount acc = accountDao.fetchAccount(internetBanking.getOpenAccount().getAccountNumber());
			return acc;
		}
		else 
			 throw new AtlanticException("Problem in service");
			
	}
}












/*try {
	LoginEntity loginDetails = loginDAO.login(loginDTO);
	return true;
} catch (UserLoginException nre) {
	return false;

}

*/








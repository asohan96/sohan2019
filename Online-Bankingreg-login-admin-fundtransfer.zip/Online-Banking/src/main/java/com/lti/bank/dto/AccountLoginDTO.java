package com.lti.bank.dto;

public class AccountLoginDTO {

	private long userId;
private String loginPassword;

public long getUserId() {
	return userId;
}
public void setUserId(long userId) {
	this.userId = userId;
}
public String getLoginPassword() {
	return loginPassword;
}
public void setLoginPassword(String loginPassword) {
	this.loginPassword = loginPassword;
}
}

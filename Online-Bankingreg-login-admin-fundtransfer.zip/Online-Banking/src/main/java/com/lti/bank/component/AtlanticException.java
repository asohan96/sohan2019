package com.lti.bank.component;

public class AtlanticException extends RuntimeException {

	public AtlanticException() {
		super();
		
	}

	public AtlanticException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public AtlanticException(String message, Throwable cause) {
		super(message, cause);
	
	}

	public AtlanticException(String message) {
		super(message);
	
	}

	public AtlanticException(Throwable cause) {
		super(cause);
		
	}
	

}

package com.lti.bank.dto;

public class CredentialsDTO {
private long userId;
private String loginPassword;
private String newLoginPassword;
private String confirmNewLoginPassword;
private String newTransactionPassword;
private String confirmNewTransactionPassword;


public String getLoginPassword() {
	return loginPassword;
}
public void setLoginPassword(String loginPassword) {
	this.loginPassword = loginPassword;
}
public long getUserId() {
	return userId;
}
public void setUserId(long userId) {
	this.userId = userId;
}
public String getNewLoginPassword() {
	return newLoginPassword;
}
public void setNewLoginPassword(String newLoginPassword) {
	this.newLoginPassword = newLoginPassword;
}
public String getConfirmNewLoginPassword() {
	return confirmNewLoginPassword;
}
public void setConfirmNewLoginPassword(String confirmNewLoginPassword) {
	this.confirmNewLoginPassword = confirmNewLoginPassword;
}
public String getNewTransactionPassword() {
	return newTransactionPassword;
}
public void setNewTransactionPassword(String newTransactionPassword) {
	this.newTransactionPassword = newTransactionPassword;
}
public String getConfirmNewTransactionPassword() {
	return confirmNewTransactionPassword;
}
public void setConfirmNewTransactionPassword(String confirmNewTransactionPassword) {
	this.confirmNewTransactionPassword = confirmNewTransactionPassword;
}
}

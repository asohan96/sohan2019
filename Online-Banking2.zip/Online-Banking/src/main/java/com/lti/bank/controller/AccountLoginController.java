package com.lti.bank.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.lti.bank.dao.AccountDao;
import com.lti.bank.dto.AccountLoginDTO;
import com.lti.bank.entity.InternetBanking;
import com.lti.bank.entity.OpenAccount;
import com.lti.bank.service.AccountLoginService;

@Controller
@SessionAttributes("account")
public class AccountLoginController {
	@Autowired
	private AccountLoginService loginService;
	
	
	@RequestMapping(path="/signIn", method=RequestMethod.POST)
	public String signInSuccessfull(AccountLoginDTO accountLoginDTO,Map<String, Object> model) {		
		OpenAccount acc = loginService.validAccountUser(accountLoginDTO);
		//InternetBanking int=changepass.validuser(dto);
		//int.setLoginPassword(dto.getNewPassword);
		//int.setTransactionPassword(dto.getNewTransactionPassword);\
		//dao.save(int);
		
		if(acc != null) {
			model.put("account", acc);
		return "/atlantic-dashboard.jsp";}
		else
			return "/atlantic-account-application-unsuccessfull.jsp";
			
	}
}

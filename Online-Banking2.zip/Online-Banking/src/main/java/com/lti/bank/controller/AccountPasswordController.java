package com.lti.bank.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lti.bank.dto.AccountLoginDTO;
import com.lti.bank.dto.PasswordDTO;
import com.lti.bank.entity.OpenAccount;
import com.lti.bank.service.ChangePasswordService;

@Controller
public class AccountPasswordController {
	@Autowired
		private ChangePasswordService changePasswordService;

	@RequestMapping(path="/change-password", method=RequestMethod.POST)
	public String changePassword(PasswordDTO passwordDTO,Map<String, Object> model) {		
		OpenAccount acc = changePasswordService.validAccountUser(passwordDTO);
		//InternetBanking int=changepass.validuser(dto);
		//int.setLoginPassword(dto.getNewPassword);
		//int.setTransactionPassword(dto.getNewTransactionPassword);\
		//dao.save(int);
		
		if(acc != null) {
			model.put("account", acc);
		return "/atlantic-dashboard.jsp";}
		else
			return "/atlantic-account-application-unsuccessfull.jsp";
			
	}



}

package com.lti.bank.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.bank.dao.AccountDao;
import com.lti.bank.dto.OpenAccountDTO;
import com.lti.bank.entity.OpenAccount;
import com.lti.bank.entity.InternetBanking;

@Service
public class OpenAccountService {
	@Autowired
	private AccountDao genericDao;

	@Transactional
	public boolean openAccountService(OpenAccountDTO openAccountDTO) {
		
/*	accountApplication.set	
		Date date1;
		try {// dd-MM-yyyy
			 date1 = new SimpleDateFormat("yyyy-MM-dd").parse(openAccountDTO.getDateOfBirth());
			
		} catch (ParseException e) {
		}
		int age=(Integer)(new Date() - date1);*/
//		double savingInitialBalance = 1000;
		//if ((openAccountDTO.getInitialBalance() >= savingInitialBalance && openAccountDTO.getAccountType().equals("SavingAccount")) || openAccountDTO.getAccountType().equals("CurrentAccount"))
			if (
(openAccountDTO.getOccupationType().equals("Government") && openAccountDTO.getGrossAnnualIncome()>=250000 && (openAccountDTO.getAccountType().equals("CurrentAccount") || openAccountDTO.getAccountType().equals("SavingAccount")) ||
(openAccountDTO.getOccupationType().equals("Private") && openAccountDTO.getGrossAnnualIncome()>=400000 && (openAccountDTO.getAccountType().equals("CurrentAccount") || openAccountDTO.getAccountType().equals("SavingAccount")) ||
(openAccountDTO.getOccupationType().equals("Business") && openAccountDTO.getGrossAnnualIncome()>=350000 && (openAccountDTO.getAccountType().equals("CurrentAccount") || openAccountDTO.getAccountType().equals("SavingAccount")) ||
(openAccountDTO.getOccupationType().equals("Others") && openAccountDTO.getAccountType().equals("CurrentAccount")
		)))))
					{
			OpenAccount accountApplication = new OpenAccount();
			// account number auto generation..no need to set
			accountApplication.setAccountType(openAccountDTO.getAccountType());
			accountApplication.setAccountDate(new Date());
			accountApplication.setTitle(openAccountDTO.getTitle());
			accountApplication.setFirstName(openAccountDTO.getFirstName());
			accountApplication.setMiddleName(openAccountDTO.getMiddleName());
			accountApplication.setLastName(openAccountDTO.getLastName());
			accountApplication.setFatherName(openAccountDTO.getFatherName());
			accountApplication.setMobileNumber(openAccountDTO.getMobileNumber());
			accountApplication.setEmailId(openAccountDTO.getEmailId());
			accountApplication.setAadharCardNumber(openAccountDTO.getAadharCardNumber());
			try {// dd-MM-yyyy
				Date date = new SimpleDateFormat("yyyy-MM-dd").parse(openAccountDTO.getDateOfBirth());
				accountApplication.setDateOfBirth(date);
			} catch (ParseException e) {
			}
			accountApplication.setResidentialAddressLine1(openAccountDTO.getResidentialAddressLine1());
			accountApplication.setResidentialAddressLine2(openAccountDTO.getResidentialAddressLine2());
			accountApplication.setResidentialLandmark(openAccountDTO.getResidentialLandmark());
			accountApplication.setResidentialState(openAccountDTO.getResidentialState());
			accountApplication.setResidentialCity(openAccountDTO.getResidentialCity());
			accountApplication.setResidentialPincode(openAccountDTO.getResidentialPincode());
			accountApplication.setPermanentAddressLine1(openAccountDTO.getPermanentAddressLine1());
			accountApplication.setPermanentAddressLine2(openAccountDTO.getPermanentAddressLine2());
			accountApplication.setPermanentLandmark(openAccountDTO.getPermanentLandmark());
			accountApplication.setPermanentState(openAccountDTO.getPermanentState());
			accountApplication.setPermanentCity(openAccountDTO.getPermanentCity());
			accountApplication.setPermanentPincode(openAccountDTO.getPermanentPincode());
			accountApplication.setAtmCard(openAccountDTO.getAtmCard());
					//string a=convert accno into string
					//string b=a.substring(int beginIndex, int endIndex)
					//accountApplication.setIfscCode("ATLA"+"102");
					//auto generate ifsc code
			accountApplication.setOccupationType(openAccountDTO.getOccupationType());
			accountApplication.setGrossAnnualIncome(openAccountDTO.getGrossAnnualIncome());
			genericDao.accountApproval(accountApplication);
			
			InternetBanking netbanking = new InternetBanking();
			netbanking.setOpeningAccount(accountApplication);
			netbanking.setUserId(accountApplication.getAccountNumber());
			netbanking.setLoginPassword(openAccountDTO.getLoginPassword());
			netbanking.setTransactionPassword(openAccountDTO.getTransactionPassword());
			genericDao.registerForInternetBanking(netbanking);
			return true;
		} else
			return false;
	}
}

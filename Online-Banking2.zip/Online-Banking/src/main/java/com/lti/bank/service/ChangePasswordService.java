package com.lti.bank.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.bank.dao.LoginDao;
import com.lti.bank.dto.PasswordDTO;
import com.lti.bank.entity.InternetBanking;

@Service
public class ChangePasswordService {
	@Autowired
	private LoginDao loginDao;
	public InternetBanking validAccountUser(PasswordDTO passwordDTO)
	{
		InternetBanking internetBanking = loginDao.findUserId(passwordDTO.getLoginPassword());
		
		if(internetBanking!=null)
		{
			internetBanking.setLoginPassword(passwordDTO.getNewLoginPassword());
			internetBanking.setTransactionPassword(passwordDTO.getNewTransactionPassword());
			loginDao.
		}
}
}
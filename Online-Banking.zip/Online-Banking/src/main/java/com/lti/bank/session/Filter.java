package com.lti.bank.session;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public interface Filter {
	public void destroy();
    public void init(FilterConfig config);
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain);
    
}

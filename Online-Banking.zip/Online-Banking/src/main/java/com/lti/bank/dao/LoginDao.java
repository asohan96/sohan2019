package com.lti.bank.dao;

import org.springframework.stereotype.Repository;

import com.lti.bank.entity.InternetBanking;

@Repository
public class LoginDao extends AccountDao {
	
	public InternetBanking findUserId(long userId)
	{
		return entityManager.find(InternetBanking.class, userId);
	}
}

package com.lti.bank.dto;



public class OpenAccountDTO {

	private String accountType;    
	//private double initialBalance;
	private String title;
	private String firstName;
	private String middleName;
	private String lastName;
	private String fatherName;
	private long mobileNumber;			
	private String emailId; 
	private long aadharCardNumber;		
	private String dateOfBirth;				
	
	//residential address variables
	private String residentialAddressLine1;
	private String residentialAddressLine2;
	private String residentialLandmark;
	private String residentialState;
	private String residentialCity;
	private int residentialPincode;
	//permanent address variables
	private String permanentAddressLine1;
	private String permanentAddressLine2;
	private String permanentLandmark;
	private String permanentState;
	private String permanentCity;
	private int permanentPincode;
	private String atmCard;
	private String occupationType;
	private double grossAnnualIncome; 
	private String securityQuestion;
	private String answer;
	
	//upload document-remaining and its getter setter
	public String getAtmCard() {
		return atmCard;
	}
	public String getSecurityQuestion() {
		return securityQuestion;
	}
	public void setSecurityQuestion(String securityQuestion) {
		this.securityQuestion = securityQuestion;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getOccupationType() {
		return occupationType;
	}
	public void setOccupationType(String occupationType) {
		this.occupationType = occupationType;
	}
	public double getGrossAnnualIncome() {
		return grossAnnualIncome;
	}
	public void setGrossAnnualIncome(double grossAnnualIncome) {
		this.grossAnnualIncome = grossAnnualIncome;
	}
	public void setAtmCard(String atmCard) {
		this.atmCard = atmCard;
	}
	private String loginPassword;
	private String transactionPassword;
	
	public String getLoginPassword() {
		return loginPassword;
	}
	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}
	public String getTransactionPassword() {
		return transactionPassword;
	}
	public void setTransactionPassword(String transactionPassword) {
		this.transactionPassword = transactionPassword;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	/*public double getInitialBalance() {
		return initialBalance;
	}
	public void setInitialBalance(double initialBalance) {
		this.initialBalance = initialBalance;
	}*/
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMiddleName() {
		return middleName;
	}
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getFatherName() {
		return fatherName;
	}
	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public long getAadharCardNumber() {
		return aadharCardNumber;
	}
	public void setAadharCardNumber(long aadharCardNumber) {
		this.aadharCardNumber = aadharCardNumber;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getResidentialAddressLine1() {
		return residentialAddressLine1;
	}
	public void setResidentialAddressLine1(String residentialAddressLine1) {
		this.residentialAddressLine1 = residentialAddressLine1;
	}
	public String getResidentialAddressLine2() {
		return residentialAddressLine2;
	}
	public void setResidentialAddressLine2(String residentialAddressLine2) {
		this.residentialAddressLine2 = residentialAddressLine2;
	}
	public String getResidentialLandmark() {
		return residentialLandmark;
	}
	public void setResidentialLandmark(String residentialLandmark) {
		this.residentialLandmark = residentialLandmark;
	}
	public String getResidentialState() {
		return residentialState;
	}
	public void setResidentialState(String residentialState) {
		this.residentialState = residentialState;
	}
	public String getResidentialCity() {
		return residentialCity;
	}
	public void setResidentialCity(String residentialCity) {
		this.residentialCity = residentialCity;
	}
	public int getResidentialPincode() {
		return residentialPincode;
	}
	public void setResidentialPincode(int residentialPincode) {
		this.residentialPincode = residentialPincode;
	}
	public String getPermanentAddressLine1() {
		return permanentAddressLine1;
	}
	public void setPermanentAddressLine1(String permanentAddressLine1) {
		this.permanentAddressLine1 = permanentAddressLine1;
	}
	public String getPermanentAddressLine2() {
		return permanentAddressLine2;
	}
	public void setPermanentAddressLine2(String permanentAddressLine2) {
		this.permanentAddressLine2 = permanentAddressLine2;
	}
	public String getPermanentLandmark() {
		return permanentLandmark;
	}
	public void setPermanentLandmark(String permanentLandmark) {
		this.permanentLandmark = permanentLandmark;
	}
	public String getPermanentState() {
		return permanentState;
	}
	public void setPermanentState(String permanentState) {
		this.permanentState = permanentState;
	}
	public String getPermanentCity() {
		return permanentCity;
	}
	public void setPermanentCity(String permanentCity) {
		this.permanentCity = permanentCity;
	}
	public int getPermanentPincode() {
		return permanentPincode;
	}
	public void setPermanentPincode(int permanentPincode) {
		this.permanentPincode = permanentPincode;
	}
	
}	 